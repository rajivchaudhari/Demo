import { Component, OnInit, Inject } from '@angular/core';

@Component({
  selector: 'app-view-bill-products',
  templateUrl: './view-bill-products.component.html',
  styleUrls: ['./view-bill-products.component.scss']
})
export class ViewBillProductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
